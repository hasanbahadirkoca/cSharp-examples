﻿using System;

namespace example_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             *  Simple username and password authentication app with do - while(true) loop
             * 
             *  Username and Password is "admin".
             *  
             */


            while (true)
            {
                Console.Write("Username: ");
                String userName = Console.ReadLine();
                Console.Write("Password: ");
                String userPass = Console.ReadLine();

                if (userName == "admin" && userPass == "admin")
                {
                    Console.WriteLine("Login succesfully!");
                    return;
                }
                else
                {
                    Console.WriteLine("Username or password is wrong.\nPlease try again!");
                }
            }
        }
    }
}
